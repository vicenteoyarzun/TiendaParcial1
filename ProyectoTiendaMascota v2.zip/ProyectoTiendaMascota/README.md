# TiendaParcial1
Evaluacion parcial 1 Fullstack

#Integrantes:
-Tomás López
-Vicente Oyarzún
-Samuel Pérez
